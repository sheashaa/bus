﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BingMapsRESTToolkit
{
    class Suggestion : Resource
    {

    }
}
